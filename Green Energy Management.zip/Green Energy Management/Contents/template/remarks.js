google.charts.load("current", {packages:['corechart']});
google.charts.setOnLoadCallback(drawChart);
var data;
function drawChart() {
    data = google.visualization.arrayToDataTable([
        ["Month", "Unit", { role: "style" } ],
        ["Ideal",200,"green"],
        ["Jan", 201, "gold"],
        ["Feb", 120, "gold"],
        ["Mar", 260, "gold"],
        ["Apr", 240, "gold"]
        
    ]);

    var view = new google.visualization.DataView(data);
    view.setColumns([0, 1,
                    { calc: "stringify",
                        sourceColumn: 1,
                        type: "string",
                        role: "annotation" },
                    2]);

    var options = {
        title: "Electricity units consumed / month",
        width: 350,
        height: 400,
        bar: {groupWidth: "80%"}, // Adjust the percentage for the gap between columns
        legend: { position: "none" },
    };
    var chart = new google.visualization.ColumnChart(document.getElementById("chart"));
    chart.draw(view, options);

    var units;
    var message = document.getElementById("p");
    if(data){
        for(var i=0; i<data.getNumberOfRows(); i++){
            units = data.getValue(i,1);
            if(units<=200){
                message.innerHTML = "Focus on minimizing standby power";
            }
            else if(units>200 && units<250){
                message.innerHTML = "Implement energy-efficient appliances";
            }
            else if(units>=250 && units < 300){
                message.innerHTML = "Optimize lighting usage";
            }
	    else if(units>=300 && units < 350){
                message.innerHTML = "Consider renewable energy options";
            }
    }
    }
    else {
        console.log("Data is not available yet.");
    }
}
