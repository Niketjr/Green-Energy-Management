from fileinput import filename
from flask import Flask,render_template,request,redirect,flash
import mysql.connector
try:
    con = mysql.connector.connect(host="localhost", user="root", passwd="Y@nkyDodle75",db="nnn")
    if con.is_connected():
        mycursor=con.cursor()
    else:
        print("Not connected")
except mysql.connector.Error as e:
    print("Error",e)
    
else:
    app = Flask(__name__,template_folder='template',static_url_path="/static")

    @app.route('/')
    def first_page():
        return render_template('login.html')

    @app.route('/validate_login', methods=['POST'])
    def validate_login():
        global username
        username = request.form['username']
        password = request.form['password']

        # Replace with your actual validation logic
        q2="select * from users where username='%s';"%username
        mycursor.execute(q2)
        r1=mycursor.fetchone()
        if not r1:
            flash("User not found. Please sign up","danger")
            return redirect('/login')
        elif username == r1[0] and password == r1[1]:
            return redirect('/success')
        else:
            flash("Login failed. Please check your credentials.","danger")
            return redirect('/login')

    @app.route('/validate_signup', methods=['POST'])
    def validate_signup():
        usr = request.form['username']
        passwd = request.form['pwd']
        cpasswd = request.form['cpwd']

        # Replace with your actual validation logic
        if passwd == cpasswd:
            q1="insert into users(username,password) values('%s','%s');"%(usr,passwd)
            mycursor.execute(q1)
            con.commit()
            return redirect('/login')
        else:
            flash("Signup failed. Please check your credentials.")
            return redirect('/login')

    #@app.route('/validate_survey', methods=['POST'])
    #def validate_survey():
        #rad1 = request.form['YesNo1']

    @app.route('/validate_survey', methods=['POST'])
    def validate_survey():
        units = request.form['Units']
        meterNo = request.form['MeterNo']
        pincode = request.form['Pin']
        q3="insert into survey1 values(now(),'%s','%s','%s','%s');"%(username,units,meterNo,pincode)
        mycursor.execute(q3)
        con.commit()
        q4="select count(*),date_format(Date_Time,'%%m') as month,max(Date_Time) from survey1 where username in (select username from survey1 where username='%s') group by month;"%username
        mycursor.execute(q4)
        entry=mycursor.fetchall()
        for i in entry:
            if i[0]>1:
                month=i[1]
                dateTime=i[2]
                q5="delete from survey1 where username='%s' and date_format(Date_Time,'%%m')='%s' and Date_Time<>'%s';"%(username,month,dateTime)
                mycursor.execute(q5)
                con.commit()
        f=request.files['EPAinput']
        if f.filename != '':
            f.save(f.filename)
        f=request.files['E-bill'] 
        if f.filename != '':
            f.save(f.filename)
        f=request.files['Solar-bill']
        if f.filename != '':
            f.save(f.filename)
        points=0
        E_Vehicle = request.form['YesNo1']
        if E_Vehicle == 'Yes':
            points+=100
        Solar_Panel = request.form['YesNo2']
        if Solar_Panel == 'Yes':
            points+=200
        if int(units) in range(0,101):
            points+=100
        elif int(units) in range(101,201):
            points+=80
        elif int(units) in range(201,251):
            points+=60
        elif int(units) in range(251,301):
            points+=40
        elif int(units) in range(301,351):
            points+=20
        else:
            points+=0
        q6="insert into user_points values(now(),'%s','%s');"%(username,points)
        mycursor.execute(q6)
        con.commit()
        q7="select count(*),date_format(Date_Time,'%%m') as month,max(Date_Time) from user_points where username in (select username from user_points where username='%s') group by month;"%username
        mycursor.execute(q7)
        pointEntry=mycursor.fetchall()
        for i in pointEntry:
            if i[0]>1:
                month1=i[1]
                dateTime1=i[2]
                q8="delete from user_points where username='%s' and date_format(Date_Time,'%%m')='%s' and Date_Time<>'%s';"%(username,month1,dateTime1)
                mycursor.execute(q8)
                con.commit()
        return redirect('/success')

    @app.route('/success')
    def user_page():
        return render_template('user.html')

    @app.route('/signup')
    def signup_page():
        return render_template('signup.html')

    @app.route('/login')
    def login_page():
        return render_template('login.html')

    @app.route('/survey')
    def survey_page():
        return render_template('survey.htm')

    @app.route('/rewards')
    def rewards_page():
        q10="select sum(points),username from user_points where username='%s' group by username;"%username
        mycursor.execute(q10)
        user_points=mycursor.fetchone()
        return render_template('rewards.htm',points=user_points[0])

    @app.route('/rewardspage')
    def rewardspage_page():
        return render_template('rewardspage.htm')

    @app.route('/remarks')
    def remarks_page():
        #q9="select units from survey1 where username='%s' and date_format(Date_Time,'%%m')='%s';"%(username,'02')
        #mycursor.execute(q9)
        #Ufeb1=mycursor.fetchone()
        return render_template('remarks.htm')

    @app.route('/leaderboard')
    def leaderboard_page():
        q11="select username,sum(points) as points from user_points group by username order by points;"
        mycursor.execute(q11)
        leaderboard = mycursor.fetchall()
        l_leaderboard = len(leaderboard)
        p1 = 0
        p2 = 0
        p3 = 0
        p4 = 0
        p5 = 0
        if l_leaderboard == 1:
            us1 = leaderboard[0][0]
            p1 = leaderboard[0][1]
            us2 = "user 2"
            us3 = "user 3"
            us4 = "user 4"
            us5 = "user 5"
        elif l_leaderboard == 2:
            us1 = leaderboard[0][0]
            p1 = leaderboard[0][1]
            us2 = leaderboard[1][0]
            p2 = leaderboard[1][1]
            us3 = "user 3"
            us4 = "user 4"
            us5 = "user 5"
        elif l_leaderboard == 3:
            us1 = leaderboard[0][0]
            p1 = leaderboard[0][1]
            us2 = leaderboard[1][0]
            p2 = leaderboard[1][1]
            us3 = leaderboard[2][0]
            p3 = leaderboard[2][1]
            us4 = "user 4"
            us5 = "user 5"
        elif l_leaderboard == 4:
            us1 = leaderboard[0][0]
            p1 = leaderboard[0][1]
            us2 = leaderboard[1][0]
            p2 = leaderboard[1][1]
            us3 = leaderboard[2][0]
            p3 = leaderboard[2][1]
            us4 = leaderboard[3][0]
            p4 = leaderboard[3][1]
            us5 = "user 5"
        elif l_leaderboard == 0:
            us1 = "user 1"
            us2 = "user 2"
            us3 = "user 3"
            us4 = "user 4"
            us5 = "user 5"
        else:
            us1 = leaderboard[0][0]
            p1 = leaderboard[0][1]
            us2 = leaderboard[1][0]
            p2 = leaderboard[1][1]
            us3 = leaderboard[2][0]
            p3 = leaderboard[2][1]
            us4 = leaderboard[3][0]
            p4 = leaderboard[3][1]
            us5 = leaderboard[4][0]
            p5 = leaderboard[4][1]
        return render_template('leaderboard.htm',u1=us1,u2=us2,u3=us3,u4=us4,u5=us5,P1=p1,P2=p2,P3=p3,P4=p4,P5=p5)
    

    if __name__ == '__main__':
        app.secret_key = 'super secret key'
        app.config['SESSION_TYPE'] = 'filesystem'
        app.run(debug=True)
    con.close()
